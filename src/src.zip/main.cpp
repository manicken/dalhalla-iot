/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/
#if defined(ESP32) || defined(ESP8266)

#include "main.h"

#include <DALHAL/Core/Types/DALHAL_ZeroCopyString.h>
#include <DALHAL/Core/Manager/DALHAL_GPIO_Manager.h>

#if defined(ESP32)
#include <SD_MMC.h>
#endif

#define BUILD_VER "1.0"

void Timer_SyncTime() {
    DEBUG_UART.println("Timer_SyncTime");
    NTP::NTPConnect();
    tmElements_t now2;
    breakTime(time(nullptr), now2);
    int year = (int)now2.Year + 1970;
    setTime(now2.Hour+1, now2.Minute, now2.Second, now2.Day, now2.Month, year);
}

#if defined(DALHAL_H_)
void Alarm_SendToHalCmdExec(const OnTickExtParameters *param)
{
    DEBUG_UART.println("Alarm_SendToHalCmdExec");
    const AsStringParameter* casted_param = static_cast<const AsStringParameter*>(param);
    if (casted_param != nullptr)
    {
        DALHAL::ZeroCopyString zcCmd(casted_param->str.c_str());
        //std::string dummy;
        DALHAL::CommandExecutor::execute(zcCmd,nullptr);
    }
}
#endif

Scheduler::NameToFunction nameToFunctionList[] = {
//   name         , onTick            , onTickExt
    {"ntp_sync"   , &Timer_SyncTime   , nullptr           }
#if defined(DALHAL_H_)
    ,{"halcmd"     , nullptr           , &Alarm_SendToHalCmdExec}
#endif
};

/**************************************************************************/
/**************************************************************************/
/**************************************************************************/

void setup() {
    DALHAL::GPIO_manager::triStateAvailablePins();

    if (Info::resetReason_is_crash(true)) {
        
        System::failsafeLoop();
    }
    DEBUG_UART.begin(115200);
    DEBUG_UART.setDebugOutput(true);

    DEBUG_UART.println(F("\r\n!!!!!Start of MAIN Setup!!!!!\r\n"));
    Info::PrintHeapInfo();

    DEBUG_UART.println(Info::getResetReasonStr());

    System::Setup();

    MainConfig::begin();

#if defined(ESP32) && defined(FSBROWSER_SYNCED_WS_H_)
    if (InitSD_MMC()) FSBrowser::fsOK = true;
#endif
#if defined(USE_DISPLAY)
    init_display();
#endif
    WiFi.setSleep(false);

#ifdef WIFI_MANAGER_WRAPPER_H_
#if defined(USE_DISPLAY)
    bool connected = WiFiManagerWrapper::Setup(display);
#else
    bool connected = WiFiManagerWrapper::Setup();
#endif
#endif
    OTA::setup();

    Scheduler::setup(nameToFunctionList, sizeof(nameToFunctionList) / sizeof(nameToFunctionList[0]));

    Info::startTime = now();
    HeartbeatLed::setup();
#if defined(ESP32) && !defined(seeed_xiao_esp32c3)
    System::Start_MDNS();
#endif
    
#if defined(ESP32) && !defined(esp32c3)
    File test = SD_MMC.open("/StartTimes.log", "a", true);
    test.println(Time_ext::GetTimeAsString(now()).c_str());
    test.close();
#endif

#ifdef DALHAL_H_
    DALHAL::begin();
#endif
    webserver.begin();

    // make sure that the following are allways at the end of this function
    //Info::PrintHeapInfo();
    DEBUG_UART.println(F("\r\n!!!!!End of MAIN Setup!!!!!\r\n"));
    delay(0);
}

void loop() {
    ArduinoOTA.handle();
    HeartbeatLed::task();
    Scheduler::HandleAlarms();
#ifdef DALHAL_H_
    DALHAL::loop();
#endif
    
#if defined(ESP8266)
    MDNS.update(); // this is only required on esp8266
#endif
    
#ifdef WIFI_MANAGER_WRAPPER_H_
    WiFiManagerWrapper::Task();
#endif
}

#if defined(USE_DISPLAY)
void init_display(void)
{
    delay(1000);
    Wire.begin(21, 22, 100000); // SDA=21, SCL=22
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
        DEBUG_UART.println(F("OLED init fail"));
        return;
    }

    DEBUG_UART.println(F("OLED OK"));
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0,0);
    //display.println(F("Hello ESP32!"));
    display.display(); // <--- push buffer to screen
}
#endif


#endif