/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once

#include <Arduino.h>
#include <DALHAL/Support/DALHAL_DeleterTemplate.h> // Deleter
#include "DALHAL_SCRIPT_ENGINE_IfStatement.h"

namespace DALHAL {
    namespace ScriptEngine {

        // Forward declare IfBlock, currently not needed but keep it here if we somewhere in the future want to do it
        struct IfBlock;

        /** StatementBlock contains either a IfBlock or a ExecBlock */
        struct StatementBlock
        {
            DALHAL_NOCOPY_NOMOVE(StatementBlock);

            void* context;
            HALOperationResult (*handler)(void* context);
            Deleter deleter;

            StatementBlock();
            ~StatementBlock();
            
            void Set(ScriptTokens& tokens);
        };

        

    }
}