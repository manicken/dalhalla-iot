/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once

#include "DALHAL_TX433_Unit.h"

#include <Arduino.h> // Needed for String class
#include <ArduinoJson.h>

#include <DALHAL/Core/Device/DALHAL_Device.h>
#include <DALHAL/Core/Types/DALHAL_Registry.h>

#define DALHAL_KEYNAME_TX433_UNITS "units"

#include <DALHAL/Config/DALHAL_ReactiveConfig.h>
#if USING_REACTIVE(TX433)
#include "DALHAL_TX433_Reactive.h"
using TX433_DeviceBase = DALHAL::TX433_Reactive;
#else
using TX433_DeviceBase = DALHAL::Device;
#endif

namespace DALHAL {

    class TX433 : public TX433_DeviceBase {
    public: // public static fields and exposed external structures
        static const Registry::DefineBase RegistryDefine;
        static Device* Create(DeviceCreateContext& context);

    private:
        uint8_t pin = 0; // if pin would be used
        Device** units;
        int unitCount;

    public:
        TX433(DeviceCreateContext& context);
        ~TX433() override;

        DeviceFindResult findDevice(UIDPath& path, Device*& outDevice) override;
        HALOperationResult write(const HALWriteStringRequestValue &val) override;

        String ToString() override;
    };
}