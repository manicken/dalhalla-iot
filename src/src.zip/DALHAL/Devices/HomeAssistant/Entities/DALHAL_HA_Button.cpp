/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#include "DALHAL_HA_Button.h"
#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_DeviceDiscovery.h>
#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_CountingPubSubClient.h>
#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_Constants.h>

#include <DALHAL/Core/JsonConfig/DALHAL_JSON_Config_Strings.h>
#include <DALHAL/Support/DALHAL_Logger.h>
#include <DALHAL/Core/JsonConfig/DALHAL_ArduinoJSON_ext.h>

#include "DALHAL_HA_Button_JSON_Schema.h"

namespace DALHAL {
    constexpr Registry::DefineBase Button::RegistryDefine = {
        Create,
        &JsonSchema::HA_Button,
    };

    void Button::SendDeviceDiscovery(PubSubClient& mqtt, const JsonVariant& jsonObj, TopicBasePath& topicBasePath) {
        const char* cmdTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::Command);
        PSC_JsonWriter::printf_str(mqtt, JSON(,"command_topic":"%s"), cmdTopicStr);
    }
    
    Button::Button(HA_CreateFunctionContext& context) : Device(context.deviceType), mqttClient(context.mqttClient)  {
        const JsonVariant& jsonObj = *(context.jsonObjItem);
        const char* uidStr = GetAsConstChar(jsonObj, DALHAL_KEYNAME_UID);
        uid = encodeUID(uidStr);
        const char* deviceId_cStr = (*(context.jsonObjRoot))["deviceId"];
  
        topicBasePath.Set(deviceId_cStr, uidStr);

        if (ValidateJsonStringField(jsonObj, "target")) {
            ZeroCopyString zcSrcDeviceUidStr = GetAsConstChar(jsonObj, "target");
            cda = new CachedDeviceAccess();
            if (cda->Set(zcSrcDeviceUidStr) == false) {
                delete cda;
                cda = nullptr;
            }
        } else {
            cda = nullptr;
        }
        //refreshMs = ParseRefreshTimeMs(jsonObj, 5000);

        HA_DeviceDiscovery::SendDiscovery(mqttClient, deviceId_cStr, context.deviceType, uidStr, jsonObj, *(context.jsonGlobal), topicBasePath, Button::SendDeviceDiscovery);

        //lastMs = millis()-refreshMs; // force a direct update after start
    }
    Button::~Button() {
        delete cda;
    }

    Device* Button::Create(DeviceCreateContext& context) {
        return new Button(static_cast<HA_CreateFunctionContext&>(context));
    }

    String Button::ToString() {
        String ret;
        ret += DeviceConstStrings::uid;
        ret += decodeUID(uid).c_str();
        ret += "\",";
        ret += DeviceConstStrings::type;
        ret += this->Type;
        ret += "\"";
       
        return ret;
    }

    HALOperationResult Button::exec(const ZeroCopyString& cmd) {
        return cda->Exec();
    }

    HALOperationResult Button::exec() {
        return cda->Exec();
    }

}