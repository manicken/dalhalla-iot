/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#include "DALHAL_HA_Sensor.h"

#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_DeviceDiscovery.h>
#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_CountingPubSubClient.h>
#include <DALHAL/Devices/HomeAssistant/Core/DALHAL_HA_Constants.h>

#include <DALHAL/Core/Manager/DALHAL_DeviceManager.h>
#include <DALHAL/Support/DALHAL_Logger.h>
#include <DALHAL/Core/JsonConfig/DALHAL_JSON_Config_Strings.h>
#include <DALHAL/Core/JsonConfig/DALHAL_ArduinoJSON_ext.h>

#include "DALHAL_HA_Sensor_JSON_Schema.h"

namespace DALHAL {

    constexpr Registry::DefineBase Sensor::RegistryDefine = {
        Create,
        &JsonSchema::HA_Sensor,
    };

    void Sensor::SendDeviceDiscovery(PubSubClient& mqtt, const JsonVariant& jsonObj, TopicBasePath& topicBasePath) {
        mqtt.write(',');
        mqtt.write('\n');
        HA_DeviceDiscovery::SendAvailabilityTopicCfg(mqtt, topicBasePath);
        const char* stateTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::State);
        mqtt.write(',');
        mqtt.write('\n');
        PSC_JsonWriter::printf_str(mqtt, JSON("state_topic":"%s"), stateTopicStr);
    }
    
    Sensor::Sensor(HA_CreateFunctionContext& context) : Device(context.deviceType), mqttClient(context.mqttClient) {
        const JsonVariant& jsonObj = *(context.jsonObjItem);
        const char* uidStr = GetAsConstChar(jsonObj, DALHAL_KEYNAME_UID);
        uid = encodeUID(uidStr);
        
        const char* deviceId_cStr = (*(context.jsonObjRoot))["deviceId"];
        topicBasePath.Set(deviceId_cStr, uidStr);

        if (ValidateJsonStringField(jsonObj, "source")) {
            ZeroCopyString zcSrcDeviceUidStr = GetAsConstChar(jsonObj, "source");
            cdr = new CachedDeviceRead();
            if (cdr->Set(zcSrcDeviceUidStr) == false) {
                // emit errors inside so no reporting is needed here unless one need to specific
                delete cdr;
                cdr = nullptr;
            }
        } else {
            cdr = nullptr;
        }
        refreshMs = ParseRefreshTimeMs(jsonObj, DALHAL_HA_SENSOR_DEFAULT_REFRESH_MS);

        //const char* cfgTopic_cStr = HA_DeviceDiscovery::GetDiscoveryCfgTopic(deviceId_cStr, type, uidStr);
        HA_DeviceDiscovery::SendDiscovery(mqttClient, deviceId_cStr, context.deviceType, uidStr, jsonObj, *(context.jsonGlobal), topicBasePath, Sensor::SendDeviceDiscovery);
        //delete[] cfgTopic_cStr;

        wasOnline = false;
        lastMs = millis()-refreshMs; // force a direct update after start
    }
    Sensor::~Sensor() {
        delete reactiveEvent;
        delete cdr;
    }

    Device* Sensor::Create(DeviceCreateContext& context) {
        return new Sensor(static_cast<HA_CreateFunctionContext&>(context));
    }

    String Sensor::ToString() {
        String ret;
        ret += DeviceConstStrings::uid;
        ret += decodeUID(uid).c_str();
        ret += "\",";
        ret += DeviceConstStrings::type;
        ret += this->Type;
        ret += "\"";
       
        return ret;
    }

    void Sensor::loop() {

        if (cdr == nullptr) return; // nothing to automate

        unsigned long now = millis();
        if (now - lastMs < refreshMs) {
            return;
        }
        lastMs = now;
        //GlobalLogger.Info(F("Sensor::loop() exec"));

        HALValue val;
        HALOperationResult res = cdr->ReadSimple(val);
        if (res == HALOperationResult::Success) {
            //GlobalLogger.Info(F("Sensor::loop() exec Success"));
            if (!wasOnline) {
                const char* availabilityTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::Status);
                bool success = mqttClient.publish(availabilityTopicStr, DALHAL_HOME_ASSISTANT_AVAILABILITY_ONLINE);
                if (success) {
                    // this will make the availability update secure and non deadlock
                    GlobalLogger.Info(F("Sensor::loop() exec Success availability changed to active"));
                    wasOnline = true;
                }
                
            }
            const char* stateTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::State);
            // if the following fails then it will try again next update
            // could implement a try again mechanism but that would require 
            // refactor to make the code DRY
            mqttClient.publish(stateTopicStr, val.toString().c_str());
           // GlobalLogger.Info(F("Sensor::loop() exec Success sent to topic: "), stateTopicStr);
        } else {
            GlobalLogger.Info(F("Sensor::loop() exec fail"));
            if (wasOnline) {
                const char* availabilityTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::Status);
                bool success = mqttClient.publish(availabilityTopicStr, DALHAL_HOME_ASSISTANT_AVAILABILITY_OFFLINE);
                
                if (success) {
                    // this will make the availability update secure and non deadlock
                    GlobalLogger.Info(F("Sensor::loop() exec Success availability changed to inactive"));
                    wasOnline = false;
                }
            }
        }
    }
    void Sensor::begin() {

    }

    HALOperationResult Sensor::read(HALValue& val) {
        if (cdr != nullptr) {
            return cdr->ReadSimple(val);
        }
        return HALOperationResult::UnsupportedOperation;

    }
    HALOperationResult Sensor::write(const HALValue& val) {
        if (val.getType() == HALValue::Type::TEST) return HALOperationResult::Success; // test write to check feature
        if (val.isNaN()) return HALOperationResult::WriteValueNaN;
        if (!wasOnline) {
            const char* availabilityTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::Status);
            wasOnline = mqttClient.publish(availabilityTopicStr, DALHAL_HOME_ASSISTANT_AVAILABILITY_ONLINE);
        }
        const char* stateTopicStr = topicBasePath.SetAndGet(TopicBasePathMode::State);
        mqttClient.publish(stateTopicStr, val.toString().c_str());
        return HALOperationResult::Success;
    };
    
}