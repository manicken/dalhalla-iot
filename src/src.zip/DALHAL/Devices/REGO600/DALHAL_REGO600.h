/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once

#define DALHAL_DEVICE_REGO600_HEATPUMP_CONTROLLER

#include <Arduino.h> // Needed for String class

#include <ArduinoJson.h>

#include <DALHAL/Core/Device/DALHAL_Device.h>
#include <DALHAL/Core/Types/DALHAL_Registry.h>

#include "DALHAL_REGO600_Register.h"
#include <DALHAL/Drivers/REGO600.h>

#include <DALHAL/Config/DALHAL_ReactiveConfig.h>
#if USING_REACTIVE(REGO600)
#include "DALHAL_REGO600_Reactive.h"
using REGO600_DeviceBase = DALHAL::REGO600_Reactive;
#else
using REGO600_DeviceBase = DALHAL::Device;
#endif

namespace DALHAL {

    class REGO600 : public REGO600_DeviceBase {
    public: // public static fields and exposed external structures
        static const Registry::DefineBase RegistryDefine;
        static Device* Create(DeviceCreateContext& context);

    private:
        uint32_t refreshTimeMs = 0;
        uint8_t rxPin = 0;
        uint8_t txPin = 0;

        /** this is only logical devices */
        Device** registerItems = nullptr;
        int registerItemCount = 0; // used by both registerItems and requestList
        Drivers::REGO600::Request** requestList = nullptr;
        Drivers::REGO600* rego600 = nullptr;
    
    public:
        REGO600(DeviceCreateContext& context);
        ~REGO600() override;

        void begin() override;
        void loop() override;
        
        DeviceFindResult findDevice(UIDPath& path, Device*& outDevice) override;

        String ToString() override;

    };
}