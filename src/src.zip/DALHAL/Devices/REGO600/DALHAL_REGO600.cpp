/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#include "DALHAL_REGO600.h"

#include <DALHAL/Support/DALHAL_Logger.h>
#include <DALHAL/Core/JsonConfig/DALHAL_JSON_Config_Strings.h>

#include <DALHAL/Support/ConvertHelper.h>

#include <DALHAL/Core/JsonConfig/DALHAL_ArduinoJSON_ext.h>
#include <DALHAL/Core/Manager/DALHAL_GPIO_Manager.h>

#include "DALHAL_REGO600_JSON_Schema.h"

namespace DALHAL {

    constexpr Registry::DefineBase REGO600::RegistryDefine = {
        Create,
        &JsonSchema::REGO600,
        DALHAL_REACTIVE_EVENT_TABLE(REGO600)
    };
    
    REGO600::REGO600(DeviceCreateContext& context) : REGO600_DeviceBase(context.deviceType) {
        const JsonVariant& jsonObj = *(context.jsonObjItem);
        const char* uidStr = jsonObj[DALHAL_KEYNAME_UID].as<const char*>();
        uid = encodeUID(uidStr);

        rxPin = GetAsUINT8(jsonObj, DALHAL_KEYNAME_RXPIN);
        txPin = GetAsUINT8(jsonObj, DALHAL_KEYNAME_TXPIN);
        GPIO_manager::ReservePin(rxPin);
        GPIO_manager::ReservePin(txPin);

        JsonArray items = jsonObj[DALHAL_KEYNAME_ITEMS];
        int itemCount = items.size();

        registerItemCount = 0;
        // first pass count valid items
        for (int i=0;i<itemCount;i++) {
            const JsonVariant item = items[i];
            if (Device::DisabledOrCommentItem(item)) { continue; }
            registerItemCount++;
        }
        // second pass
        requestList = new (std::nothrow) Drivers::REGO600::Request*[registerItemCount]();
        registerItems = new (std::nothrow) Device*[registerItemCount]();
        int index = 0;
        DeviceCreateContext createContext;
        createContext.deviceType = "REGO600reg";
        for (int i=0;i<itemCount;i++) {
            const JsonVariant& item = items[i];
            if (Device::DisabledOrCommentItem(item)) { continue; }

            createContext.jsonObjItem = &item;
            REGO600_Register* itemReg = new REGO600_Register(createContext);

            const char* regName = GetAsConstChar(item, "regname");
            const Drivers::REGO600::RegoLookupEntry* entry = Drivers::REGO600::SystemRegisterTableLockup(regName);
            if (regName == nullptr) {
                GlobalLogger.Error(F("regName not found"));
            }
            // here value is passed by ref so that REGO600 driver can access and change the value,
            // that makes REGO600register read function can then get the correct value
            const Drivers::REGO600::OpCodeInfo& info = Drivers::REGO600::getCmdInfo(0x02); // system registers only
            requestList[index] = new Drivers::REGO600::Request(
                info, 
                (entry != nullptr) ? *entry : Drivers::REGO600::ManualRawEntry, // should not be needed
                itemReg->value
            );
            registerItems[index] = itemReg;
            index++;
        }
        refreshTimeMs = ParseRefreshTimeMs(jsonObj, 0); // default to zero, note here REGO600 constructor will calculate minimum based on registerItemCount
        unsigned long requestDelayMs = 10;
        if (jsonObj.containsKey("requestDelayMs") && jsonObj["requestDelayMs"].is<unsigned long>()) {
            requestDelayMs = jsonObj["requestDelayMs"].as<unsigned long>();
        }
        rego600 = new Drivers::REGO600(rxPin, txPin, requestList, registerItemCount, refreshTimeMs, requestDelayMs);
    }

    REGO600::~REGO600() {
        if (rego600 != nullptr)
            delete rego600;
        if (requestList != nullptr) { // if for example the allocation did fail
            for (int i=0;i<registerItemCount; i++) {
                delete requestList[i];
            }
            delete[] requestList;
        }
        if (registerItems != nullptr) { // if for example the allocation did fail
            for (int i=0;i<registerItemCount; i++) {
                delete registerItems[i];
            }
            delete[] registerItems;
        }
        pinMode(rxPin, INPUT); // input
        pinMode(txPin, INPUT); // input
    }
    void REGO600::begin() {
        rego600->begin(); // this will initialize a first request
#if HAS_REACTIVE_BEGIN(REGO600)
        triggerBegin();
#endif
    }
    void REGO600::loop() {
        rego600->loop();
#if HAS_REACTIVE_CYCLE_COMPLETE(REGO600)
        if (rego600->RefreshLoopDone()) { // one hit flag check and clear if set
            triggerCycleComplete();
        }
#endif
    }

    Device* REGO600::Create(DeviceCreateContext& context) {
        return new REGO600(context);
    }

    String REGO600::ToString() {
        String ret;
        ret += DeviceConstStrings::uid;
        ret += decodeUID(uid).c_str();
        ret += "\",";
        ret += DeviceConstStrings::type;
        ret += this->Type;
        ret += "\",";
        ret += "\"items\":[";
        bool first = true;
        for (int i=0;i<registerItemCount;i++) {
            if (first == false) { ret += ","; }
            else
                first = false;
            ret += '{';
            ret += registerItems[i]->ToString();
            ret += ",\"opcode\":\"";
            ret += Convert::toHex((uint8_t)requestList[i]->info.opcode).c_str();
            ret += "\",\"addr\":\"";
            ret += Convert::toHex(requestList[i]->def.address).c_str();
            ret += "\",";
            ret += registerItems[i]->ToString();
            ret += "}";
        }
        ret += ']';
        return ret;
    }

    DeviceFindResult REGO600::findDevice(UIDPath& path, Device*& outDevice) {
        return Device::findInArray(registerItems, registerItemCount, path, this, outDevice);
    }

}