/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#include "DALHAL__Template_.h"

#include <DALHAL/Support/DALHAL_Logger.h>
#include <DALHAL/Core/JsonConfig/DALHAL_JSON_Config_Strings.h>
#include <DALHAL/Core/JsonConfig/DALHAL_ArduinoJSON_ext.h>
#include <DALHAL/Core/Manager/DALHAL_GPIO_Manager.h>

#include "DALHAL__Template__JSON_Schema.h"

namespace DALHAL {
        constexpr Registry::DefineBase _Template_::RegistryDefine = {
                
                Create,
                &JsonSchema::_Template_,
                DALHAL_REACTIVE_EVENT_TABLE(_TEMPLATE_)
        };

    _Template_::_Template_(DeviceCreateContext& context) : _Template__DeviceBase(context.deviceType) {
        const JsonVariant& jsonObj = *(context.jsonObjItem);
    }

    Device* _Template_::Create(DeviceCreateContext& context) {
        return new _Template_(context);
    }

    String _Template_::ToString() {
        String ret;
        ret += DeviceConstStrings::uid;
        ret += decodeUID(uid).c_str();
        ret += "\",";
        ret += DeviceConstStrings::type;
        ret += this->Type;
        ret += "\",";
        ret += DeviceConstStrings::pin;
        ret += std::to_string(pin).c_str();
        return ret;
    }

    void _Template_::loop() {}
    void _Template_::begin() {
#if HAS_REACTIVE_BEGIN(TEMPLATE)
        triggerBegin();
#endif        
    }
    DeviceFindResult _Template_::findDevice(UIDPath& path, Device*& outDevice) { return DeviceFindResult::SubDevicesNotSupported; }

    HALOperationResult _Template_::read(HALValue& val) {
#if HAS_REACTIVE_READ(TEMPLATE)
        triggerRead();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::write(const HALValue& val) {
        if (val.getType() == HALValue::Type::TEST) return HALOperationResult::Success; // test write to check feature
        if (val.isNaN()) return HALOperationResult::WriteValueNaN;
#if HAS_REACTIVE_WRITE(TEMPLATE)
        triggerWrite();
#endif
        return HALOperationResult::UnsupportedOperation;
    };
    HALOperationResult _Template_::read(const HALValue& bracketSubscriptVal, HALValue& val) {
#if HAS_REACTIVE_BRACKET_READ(TEMPLATE)
        triggerBracketRead();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::write(const HALValue& bracketSubscriptVal, const HALValue& val) {
#if HAS_REACTIVE_BRACKET_WRITE(TEMPLATE)
        triggerBracketWrite();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::read(const HALReadStringRequestValue& val) {
#if HAS_REACTIVE_READ(TEMPLATE)
        triggerRead();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::write(const HALWriteStringRequestValue& val) {
#if HAS_REACTIVE_WRITE(TEMPLATE)
        triggerWrite();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::read(const HALReadValueByCmd& val) {
#if HAS_REACTIVE_READ(TEMPLATE)
        triggerRead();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::write(const HALWriteValueByCmd& val) {
#if HAS_REACTIVE_WRITE(TEMPLATE)
        triggerWrite();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::exec() {
#if HAS_REACTIVE_EXEC(TEMPLATE)
        triggerExec();
#endif
        return HALOperationResult::UnsupportedOperation;
    }
    HALOperationResult _Template_::exec(const ZeroCopyString& cmd) {
#if HAS_REACTIVE_EXEC(TEMPLATE)
        triggerExec();
#endif
        return HALOperationResult::UnsupportedOperation;
    }

    Device::ReadToHALValue_FuncType _Template_::GetReadToHALValue_Function(ZeroCopyString& zcFuncName) { return nullptr; }
    Device::WriteHALValue_FuncType _Template_::GetWriteFromHALValue_Function(ZeroCopyString& zcFuncName) { return nullptr; }
    Device::Exec_FuncType _Template_::GetExec_Function(ZeroCopyString& zcFuncName) {return nullptr; } 

    Device::BracketOpRead_FuncType _Template_::GetBracketOpRead_Function(ZeroCopyString& zcFuncName) { return nullptr; }
    Device::BracketOpWrite_FuncType _Template_::GetBracketOpWrite_Function(ZeroCopyString& zcFuncName) { return nullptr; }
    
    HALValue* _Template_::GetValueDirectAccessPtr() { return nullptr; }
}