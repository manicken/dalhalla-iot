/*
  Dalhalla IoT — JSON-configured HAL/DAL + Script Engine
  HAL = Hardware Abstraction Layer
  DAL = Device Abstraction Layer

  Provides IoT firmware building blocks for home automation and smart sensors.

  Copyright (C) 2026 Jannik Svensson

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program. If not, see <https://www.gnu.org/licenses/>.
*/

#pragma once


#include <Arduino.h>

#include <ArduinoJson.h>
#include <stdlib.h>

#include <DALHAL/Core/Device/DALHAL_Device.h>
#include <DALHAL/Core/Types/DALHAL_Value.h>
#include <DALHAL/Core/Types/DALHAL_ZeroCopyString.h>

namespace DALHAL {

    class CachedDeviceAccess {
    private:
        Device* device;
        /** 
         * some devices can give direct access to the internal value
         * so in those cases this will allow that
         */
        HALValue* valueDirectAccessPtr;
        /** 
         * allows direct access to functions by name, 
         * or actually sub values defined by using # in uidPath#subItem
         */
        Device::ReadToHALValue_FuncType readToHalValueFunc;
        Device::WriteHALValue_FuncType writeFromHalValueFunc;
        Device::Exec_FuncType execFunc;
        
        Device::BracketOpRead_FuncType bracketReadFunc;
        Device::BracketOpWrite_FuncType bracketWriteFunc;
        CachedDeviceAccess* bracketAccessSubscriptOperand;
        
    public:
        CachedDeviceAccess();
        ~CachedDeviceAccess();
        bool Set(const char* uidPathAndFuncName);
        bool Set(ZeroCopyString zcStrUidPathAndFuncName);
        //CachedDeviceAccess(const char* uidPathAndFuncName);
        //CachedDeviceAccess(ZeroCopyString zcStrUidPathAndFuncName);

        HALOperationResult Exec();
        HALOperationResult WriteSimple(const HALValue& val);
        HALOperationResult ReadSimple(HALValue& val);
    };

}