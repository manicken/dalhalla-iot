function setStyles(el, styles) {
    if (typeof styles === "object") {
        for (const [name, value] of Object.entries(styles)) {
            el.style[name] = value;
        }
    }
}

function newEl(tag, attrs = {}, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'text') e.textContent = v;
      else if (k === 'cls') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    setStyles(e, attrs.styles);
    for (const c of children) if (c) e.append(c);
    return e;
  }